// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DashboardTheme/nls/strings":{_themeLabel:"Th\u00e8me du tableau de bord",_layout_default:"Mise en page par d\u00e9faut",_layout_right:"Disposition \u00e0 droite",_localized:{}}});