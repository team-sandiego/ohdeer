// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DashboardTheme/widgets/Header/nls/strings":{_widgetLabel:"Nag\u0142\u00f3wek",signin:"Zaloguj",signout:"Wyloguj",about:"Informacje o",signInTo:"Zaloguj si\u0119 do",cantSignOutTip:"Funkcja nie ma zastosowania w widoku podgl\u0105du.",_localized:{}}});