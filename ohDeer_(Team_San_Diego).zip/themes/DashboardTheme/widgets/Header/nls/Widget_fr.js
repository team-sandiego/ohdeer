// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DashboardTheme/widgets/Header/nls/strings":{_widgetLabel:"En-t\u00eate",signin:"Connexion",signout:"D\u00e9connexion",about:"A propos",signInTo:"Se connecter \u00e0",cantSignOutTip:"Cette fonction est N/D en mode d\u2019aper\u00e7u.",_localized:{}}});