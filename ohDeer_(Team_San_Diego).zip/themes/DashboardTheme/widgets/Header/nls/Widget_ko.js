// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DashboardTheme/widgets/Header/nls/strings":{_widgetLabel:"\ud5e4\ub354",signin:"\ub85c\uadf8\uc778",signout:"\ub85c\uadf8\uc544\uc6c3",about:"\uc815\ubcf4",signInTo:"\ub85c\uadf8\uc778",cantSignOutTip:"\uc774 \uae30\ub2a5\uc740 \ubbf8\ub9ac \ubcf4\uae30 \ubaa8\ub4dc\uac00 \uc81c\uacf5\ub418\uc9c0 \uc54a\uc2b5\ub2c8\ub2e4.",_localized:{}}});