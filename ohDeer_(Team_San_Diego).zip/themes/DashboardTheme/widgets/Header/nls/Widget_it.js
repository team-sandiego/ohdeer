// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DashboardTheme/widgets/Header/nls/strings":{_widgetLabel:"Intestazione",signin:"Accedi",signout:"Disconnetti",about:"Informazioni su",signInTo:"Accedi a",cantSignOutTip:"Questa funzione non \u00e8 disponibile in modalit\u00e0 anteprima.",_localized:{}}});