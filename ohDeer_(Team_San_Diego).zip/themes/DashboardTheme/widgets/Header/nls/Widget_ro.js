// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DashboardTheme/widgets/Header/nls/strings":{_widgetLabel:"Antet",signin:"Conectare",signout:"Deconectare",about:"Despre",signInTo:"Conectare la",cantSignOutTip:"Aceast\u0103 func\u0163ie nu este disponibil\u0103 \u00een modul de previzualizare.",_localized:{}}});