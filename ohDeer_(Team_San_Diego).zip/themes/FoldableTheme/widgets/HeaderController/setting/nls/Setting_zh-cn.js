// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"\u540d\u79f0",openAll:"\u5728\u4e00\u4e2a\u9762\u677f\u4e2d\u5168\u90e8\u6253\u5f00",dropDown:"\u5728\u4e0b\u62c9\u83dc\u5355\u4e2d\u663e\u793a",noGroup:"\u4e0d\u5b58\u5728\u5fae\u4ef6\u7ec4\u96c6\u3002",groupSetLabel:"\u8bbe\u7f6e\u5fae\u4ef6\u7ec4\u5c5e\u6027",_localized:{}}});